/* ===========================================================
   ATLAS - motion + interaction layer
   Tiny, dependency-free. Pure ASCII so it decodes identically
   in every browser, proxy and CDN.
   =========================================================== */
(() => {
'use strict';

const $  = (s, c = document) => c.querySelector(s);
const $$ = (s, c = document) => Array.from(c.querySelectorAll(s));
const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const lerp  = (a, b, t) => a + (b - a) * t;

const REDUCED = matchMedia('(prefers-reduced-motion: reduce)').matches;
const FINE    = matchMedia('(hover:hover) and (pointer:fine)').matches;

/* -- nav: sticky state + hide on scroll down ---------------- */
const nav = $('.nav');
let lastY = scrollY, ticking = false;

function onScroll() {
  const y = scrollY;
  if (nav) {
    nav.classList.toggle('stuck', y > 40);
    nav.classList.toggle('hide', y > lastY && y > 500);
  }
  lastY = y;
}
addEventListener('scroll', () => {
  if (ticking) return;
  ticking = true;
  requestAnimationFrame(() => { onScroll(); ticking = false; });
}, { passive: true });
onScroll();

/* -- reveal on scroll -------------------------------------- */
const reveals = $$('[data-rev]');
reveals.forEach(el => { if (el.dataset.d) el.style.setProperty('--d', el.dataset.d + 'ms'); });

if ('IntersectionObserver' in window) {
  const io = new IntersectionObserver((entries) => {
    for (const en of entries) {
      if (!en.isIntersecting) continue;
      en.target.classList.add('in');
      io.unobserve(en.target);
    }
  }, { threshold: 0.12, rootMargin: '0px 0px -6% 0px' });
  reveals.forEach(el => io.observe(el));
} else {
  reveals.forEach(el => el.classList.add('in'));
}

/* -- headline curtain reveal ------------------------------- */
const hero = $('.hero');
const masks = $$('.mask');

const lit = (m) => { m.classList.add('lit'); };

if (hero) requestAnimationFrame(() => { hero.classList.add('lit'); });

// masks inside the hero reveal immediately; the rest reveal on scroll
masks.forEach(m => {
  if (hero && hero.contains(m)) { lit(m); return; }
  const o = new IntersectionObserver(([en]) => {
    if (!en.isIntersecting) return;
    lit(m);
    o.disconnect();
  }, { threshold: 0.4 });
  o.observe(m);
});

/* -- animated counters ------------------------------------- */
const counters = $$('[data-count]');
if (counters.length) {
  const dec = (s) => (s.split('.')[1] || '').length;
  const fmt = (v, d) => (d ? v.toFixed(d) : Math.round(v).toLocaleString('en-US'));

  const run = (el) => {
    const end = parseFloat(el.dataset.count);
    const d = dec(el.dataset.count);
    if (REDUCED || el.dataset.plain) { el.textContent = fmt(end, d); return; }
    const D = 1700, t0 = performance.now();
    const step = (now) => {
      const t = clamp((now - t0) / D);
      el.textContent = fmt(end * (1 - Math.pow(1 - t, 4)), d);
      if (t < 1) requestAnimationFrame(step); else el.textContent = fmt(end, d);
    };
    requestAnimationFrame(step);
  };

  const co = new IntersectionObserver((entries) => {
    for (const en of entries) {
      if (!en.isIntersecting) continue;
      run(en.target);
      co.unobserve(en.target);
    }
  }, { threshold: 0.5 });
  counters.forEach(c => co.observe(c));
}

/* -- portfolio filter -------------------------------------- */
const chips = $$('.chip[data-filter]');
const items = $$('.item[data-cat]');
const live  = $('#filterStatus');

if (chips.length && items.length) {
  chips.forEach(chip => {
    chip.addEventListener('click', () => {
      const f = chip.dataset.filter;
      chips.forEach(c => c.setAttribute('aria-pressed', String(c === chip)));
      let shown = 0;
      items.forEach(it => {
        const ok = f === 'all' || it.dataset.cat.split(' ').includes(f);
        it.hidden = !ok;
        if (ok) shown++;
      });
      if (live) {
        live.textContent = f === 'all'
          ? 'Showing all ' + shown + ' projects.'
          : 'Showing ' + shown + ' project' + (shown === 1 ? '' : 's') + ' in this category.';
      }
    });
  });
}

/* -- FAQ: reveal on hover, and only one open at a time ----- */
const faqs = $$('.faq details');
if (faqs.length) {
  const openOne = (d) => faqs.forEach(o => { o.open = (o === d); });

  faqs.forEach(d => {
    // hover reveals the answer on desktop
    d.addEventListener('mouseenter', () => openOne(d));
    // click still works everywhere (touch + keyboard)
    d.addEventListener('toggle', () => { if (d.open) openOne(d); });
  });
}

/* -- contact form (front-end validation) -------------------- */
const form = $('#leadForm');
if (form) {
  const msg = $('#leadMsg');
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const data = new FormData(form);
    const email = String(data.get('email') || '').trim();
    const name  = String(data.get('name')  || '').trim();
    const ok = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email);
    const say = (t, bad) => {
      if (!msg) return;
      msg.textContent = t;
      msg.classList.add('on');
      msg.classList.toggle('err', !!bad);
      setTimeout(() => msg.classList.remove('on'), 6000);
    };
    if (!name) return say('Tell me your name first.', true);
    if (!ok)   return say('That email address does not look right.', true);
    say('Thanks ' + name.split(' ')[0] + ' - I reply to every enquiry within one business day. Check your inbox for a confirmation.');
    form.reset();
  });
}

/* -- hero video: pause it when it can't be seen or is
      reduced-motion, so we never burn battery for nothing --- */
(function heroVideo() {
  const v = $('#heroVideo');
  if (!v) return;

  if (REDUCED) {
    v.removeAttribute('autoplay');
    v.pause();
    return;
  }

  // if autoplay is refused (data saver, strict settings), show the poster only
  const kick = () => {
    if (v.paused) { const p = v.play(); if (p && p.catch) p.catch(() => {}); }
  };
  v.addEventListener('canplay', kick, { once: true });
  kick();

  document.addEventListener('visibilitychange', () => {
    if (document.hidden) v.pause(); else kick();
  });
})();

/* -- portfolio screenshots -----------------------------------
   One canonical file per card (see README). The image stays
   invisible in CSS until .ok is applied, so a missing file
   falls back to the styled gradient panel rather than showing
   a broken box.                                           */
$$('[data-shot]').forEach(img => {
  const show = () => {
    if (img.naturalWidth > 0) { img.classList.add('ok'); img.hidden = false; }
    else { img.hidden = true; }
  };
  if (img.complete) show();
  else {
    img.addEventListener('load', show, { once: true });
    img.addEventListener('error', () => { img.hidden = true; }, { once: true });
  }
});

/* -- smooth in-page anchors -------------------------------- */
$$('a[href^="#"]').forEach(a => {
  a.addEventListener('click', (e) => {
    const id = a.getAttribute('href');
    if (!id || id === '#' || id.length < 2) return;
    const t = document.getElementById(id.slice(1));
    if (!t) return;
    e.preventDefault();
    const y = t.getBoundingClientRect().top + scrollY - 84;
    scrollTo({ top: y, behavior: REDUCED ? 'auto' : 'smooth' });
    history.replaceState(null, '', id);
  });
});

/* -- FAQ deep-link support (AEO / shared links) ------------ */
if (location.hash.length > 1) {
  const t = document.querySelector(location.hash);
  if (t && t.tagName === 'DETAILS') {
    t.open = true;
    requestAnimationFrame(() => scrollTo({ top: t.getBoundingClientRect().top + scrollY - 100, behavior: 'auto' }));
  }
}

})();
